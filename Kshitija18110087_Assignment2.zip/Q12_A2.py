#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1 = 10
l2 = 10
l3 = 10


d = 5


# origin matrix and jacobian matrix

O0 = np.matrix([[0],[0],[0]])
O1 = np.matrix([[0],[0],[l1]])
O2 = np.matrix([[0],[l2],[l1]])
O3 = np.matrix([[0],[l2+l3],[l1]])
O4 = np.matrix([[0],[l2+l3],[l1+d]])

z0 = np.matrix([[0],[0],[1]])
z1 = np.matrix([[0],[0],[1]])
z2 = np.matrix([[0],[0],[-1]])
z3 = np.matrix([[0],[0],[-1]])

J = np.vstack([ np.hstack([O4-O0,O4-O1,z2,O4-O4]) , np.hstack([z0,z1,z2-z2,z3])])


print(J)