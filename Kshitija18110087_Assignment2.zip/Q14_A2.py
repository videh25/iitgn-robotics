#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1 = 10
l2 = 10
l3 = 10


d = 5


# origin matrix and jacobian matrix

O0 = np.matrix([[0],[0],[0]])
O1 = np.matrix([[0],[0],[0]])
O2 = np.matrix([[0],[0],[l1]])
O3 = np.matrix([[l2],[0],[l1]])

z0 = np.matrix([[0],[0],[1]])
z1 = np.matrix([[0],[0],[1]])
z2 = np.matrix([[0],[0],[1]])

J = np.vstack([ np.hstack( [O3-O0,O3-O1,O3-O2]) , np.hstack([z0,z1,z2-z2])])

print(J)