#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1 = 10
l2 = 10
l3 = 10

q1 = np.pi/6
q2 = np.pi/6

d = 5


# rotation matrix and linear matrix
R0_1 = np.matrix([[np.cos(q1),-np.sin(q1),0], [np.sin(q1),np.cos(q1),0],[0,0,1]])
d0_1 = np.matrix([[0],[0],[l1]])

R1_2 = np.matrix([[np.cos(q2),-np.sin(q2),0], [np.sin(q2),np.cos(q2),0],[0,0,1]])
d1_2 = np.matrix([[0],[l2],[0]])

R2_3 = np.matrix([[1,0,0],[0,1,0],[0,0,1]])
d2_3 = np.matrix([[0],[l3],[0]])

P3 =np.matrix([[0],[0],[d]])


H0_1 =np.vstack((np.append(R0_1, d0_1,axis =1),[0,0,0,1]))
H1_2 =np.vstack((np.append(R1_2, d1_2,axis =1),[0,0,0,1]))
H2_3 =np.vstack((np.append(R2_3, d2_3,axis =1),[0,0,0,1]))

# end effector position
# z = [[P0],[1]]
z = np.dot(H0_1,np.dot(H1_2,np.dot(H2_3,np.vstack((P3,[1]))))) 


print('P0 = ',z[0:3])