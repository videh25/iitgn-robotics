#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1 = 10
l2 = 10
x0 = 1
y0 = 1


# define initial states
q1 = 0
q2 = 0

theta1 = [q1]
theta2 = [q2]

Time = [0]

# q1 and q2 wrt x and y

for t in range(1,10000):
    Time.append(t)
    x = x0 + np.cos(np.pi*t/360)
    y = y0 + np.sin(np.pi*t/360)
    theta = np.arccos((x*x + y*y - l1*l1 - l2*l2)/(2*l1*l2))
    q1 = np.arctan(y/x) - np.arctan(l2*np.sin(theta)/(l1 +l2*np.cos(theta)))
    q2 = theta + q1
    theta1.append(q1)
    theta2.append(q2)

plt.plot(Time, theta1)
plt.plot(Time, theta2)
plt.show()
