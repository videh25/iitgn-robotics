# Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

g = 9.81
l1 = 10
l2 = 10
q1 = np.pi/6
q2 = np.pi/3
k = 10

#def origin
x_0 = 0
y_0 = 0

# define initial states

x = l1*np.cos(q1) + l2*np.cos(q2)
y = l1*np.sin(q1) + l2*np.sin(q2)

Fx = k*(x - x_0)
Fy = k*(y - y_0)

t1s = Fy*l1*np.cos(q1) - Fx*l1*np.sin(q1)
t2s = Fy*l2*np.cos(q2) - Fx*l2*np.sin(q2)

print(t1s, t2s)