#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1 = 10
l2 = 5

# define initial states
n_theta = 100
theta_start=7*np.pi/36
theta_end = 29*np.pi/36

theta1 = []
theta2 = []


for i in range (0,n_theta):

    tmp = theta_start+i*(theta_end-theta_start)/(n_theta-1)
    theta1.append(tmp)
    theta2.append(tmp)


x0 = 0
y0 = 0 

ct = 1

for THETA1 in theta1: 
    for THETA2 in theta2:
        x1 = l1*np.cos(THETA1)
        y1 = l1*np.sin(THETA1)

        x2 = x1 + l2*np.cos(THETA2) 
        y2 = y1 + l2*np.sin(THETA2)

        ct = ct + 1

        
        plt.plot([x0, x1],[y0, y1]) 
        plt.plot([x1, x2], [y1, y2])

plt.show()