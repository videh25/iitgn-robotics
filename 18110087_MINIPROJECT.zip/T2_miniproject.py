#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1 = 10
l2 = 10
x0 = 0
y0 = 0

# assuming a vertical wall, therefore Fy can be assumed to be zero 
# so that the force applied is normal to the wall

Fx = 10
Fy = 0

# define initial states
q1 = 0
q2 = 0
t1 = 0
t2 = 0

theta1 = [q1]
theta2 = [q2]
tau1 = [t1]
tau2 = [t2]

Time = [0]

# q1 and q2 wrt x and y

for t in range(1,10000):
    Time.append(t)
    x = x0 + np.cos(np.pi*t/360)
    y = y0 + np.sin(np.pi*t/360)
    theta = np.arccos((x*x + y*y - l1*l1 - l2*l2)/(2*l1*l2))
    q1 = np.arctan(y/x) - np.arctan(l2*np.sin(theta)/(l1 +l2*np.cos(theta)))
    q2 = theta + q1
    theta1.append(q1)
    theta2.append(q2)
    t1 = Fy*l1*np.cos(q1) - Fx*l1*np.sin(q1)
    t2 = Fy*l2*np.cos(q2) - Fx*l2*np.sin(q2)
    tau1.append(t1)
    tau2.append(t2)

print(t1, t2)




