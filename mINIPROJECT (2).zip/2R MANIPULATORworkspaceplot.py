import cv2
import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

l1= 7
l2= 7
theta=0
theta1=[1000]
theta2=[1000]

q1=np.pi/4  
q2=np.pi/4

# define initial states
theta = np.pi/6
x=1
y=1

plt.ion()
plt.show()

for i in range(100):

    # just by increaseing the angle by 5 deg  
    q1+=np.pi/36
    q2+=np.pi/36
    theta1.append(q1)
    theta2.append(q2) 
    
         


    # position of the linka. 
    linkpos1 = (l1 * np.cos(theta1[i]), l2 * np.sin(theta1[i]))
    linkpos2 =  (linkpos1[0]+l2 * np.cos(theta2[i]),linkpos1[1]+l2 * np.sin(theta2[i]))

    plt.clf() # clear figure before each plot

    # set axis limits. Without this the limits will be autoadjusted which will make it difficult to understand.
    plt.xlim([-20, 30])
    plt.ylim([-20, 30])

    # plot the manipulator.
    hinge = (0, 0)
    plt.plot([hinge[0], linkpos1[0]], [hinge[1], linkpos1[1]], '-o')
    plt.plot([linkpos1[0],linkpos2[0]],[linkpos1[1],linkpos2[1]], '-o')

    if round(theta2[i])==round(np.pi*29/36):
        q1=np.pi*7/36
        
    if round(theta1[i])==round(np.pi*29/36):
        print(q1)
        print(len(theta1))
        
        break

    # pause so that the figure can be seen
    plt.pause(0.0001)


plt.ioff()
plt.show()


