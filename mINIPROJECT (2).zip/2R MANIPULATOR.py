import cv2
import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# define some constants

g = 9.81
l1= 7
l2= 7
theta=0
theta1=[1000]
theta2=[1000]
q1=0
q2=0

# define initial states
omega = 0
theta = np.pi/6
x=1
y=1


# now plotting. 

plt.ion()
plt.show()

for i in range(100):

    #HERE WE CALCULATE THE ANGLES CONSIDERING THE GIVEN PATH TRAJECTORY
    
    theta = np.arccos((x*x+y*y-l1*l1-l2*l2)/(2*l1*l2))
    q1=np.arctan(y/x)-np.arctan((l2*np.sin(theta))/(l1+l2*np.cos(theta)))
    q2=theta+q1
    x+=0.2
    y+=0.2
    theta1.append(q1)
    theta2.append(q2) 


    # position of the LINK.
    linkpos1 = (l1 * np.cos(theta1[i]), l2 * np.sin(theta1[i]))
    linkpos2 =  (linkpos1[0]+l2 * np.cos(theta2[i]),linkpos1[1]+l2 * np.sin(theta2[i]))

    plt.clf() # clear figure before each plot

    # set axis limits. Without this the limits will be autoadjusted which will make it difficult to understand.
    plt.xlim([-20, 20])
    plt.ylim([-20, 10])

    # plot the pendulum.
    hinge = (0, 0)
    plt.plot([hinge[0], linkpos1[0]], [hinge[1], linkpos1[1]], '-o')
    plt.plot([linkpos1[0],linkpos2[0]],[linkpos1[1],linkpos2[1]], '-o')

    # pause so that the figure can be seen
    plt.pause(0.0001)

plt.ioff()
plt.show()





