#Kshitija Anam 18110087

import numpy as np
import scipy
import scipy.integrate
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt
import sys

# For user input
n = int(input("number of links:"))

m = (input("Enter the type of joints with spaces (eg:R R R)):"))

m_array = m.split()
m_array = np.array(m_array)
m_len = len(m_array)

if n != m_len:
    print("ERROR")
    sys.exit()

for i in range(m_len):
    if m_array[i] == 'R' or 'r' or 'P' or 'p':
        pass
    else:
        print("ERROR")
        sys.exit()


DH_mat = []
print("Enter the entries row wise (theta, alpha, a, d):")
print("Enter the entries for theta and alpha in degrees (int)")

for i in range(n):          
    temp =[]
    for j in range(4):
         temp.append(int(input()))
    DH_mat.append(temp)

DH_mat = np.array(DH_mat)

T1 = np.array([[1, 0, 0, 0],
            [0, 1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1],])

z = np.array([[0,0,1]])
p = np.array([[0,0,0]])

for i in range(n):
    theta = DH_mat[i,0]
    alpha = DH_mat[i,1]
    a = DH_mat[i,2]
    d = DH_mat[i,3]

    cos_theta = np.cos(np.deg2rad(theta))
    sin_theta = np.sin(np.deg2rad(theta))
    cos_alpha = np.cos(np.deg2rad(alpha))
    sin_alpha = np.sin(np.deg2rad(alpha))

    T = np.array([[cos_theta, -sin_theta*cos_alpha, sin_theta*sin_alpha, a*cos_theta],
            [sin_theta, cos_theta*cos_alpha, -cos_theta*sin_alpha, a*sin_theta],
            [0, sin_alpha, cos_alpha, d],
            [0, 0, 0, 1],])

    T1 = np.dot(T,T1)
    print(T1)    

    z = np.vstack((z,T1[0:3,2]))
    p = np.vstack((p,T1[0:3,3]))

P = T1[0:3,3]
print()
print(P)

# end effector position
x_pos = T[0,3]
y_pos = T[1,3]
z_pos = T[2,3]
print()
print("end effector position:")
print(np.array([x_pos,y_pos,z_pos]))
print()

J_mat = np.empty((6,n),dtype=float)

for i in range(m_len):
    if m_array[i] == 'R' or 'r':
        temp1 = P-p[0:3,i]
        tempo = np.transpose(np.cross(z[0:3,i], temp1))
        temp2 = np.transpose(z[0:3,i])
        J0 = tempo
        J1 = temp2
    elif m_array[i] == 'P' or 'p':
        temp3 = np.transpose(z[0:3,i])
        temp4 = np.transpose([0,0,0])
        J0 = temp3
        J1 = temp4

    J_mat = np.c_[([ np.r_[([(J0,J_mat)])], np.r_[([(J1,J_mat)])] ])]


print()
print(J_mat)

#As q_dot is not given, exact velocity cannot be calculated
#1st 3 rows of the J_mat matrix will be the velocity Jacobian 
# which will be helpful to calculate velocity of the end effector if q_dot is given
