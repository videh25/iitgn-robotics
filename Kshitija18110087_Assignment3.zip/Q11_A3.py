#Kshitija Anam 18110087

import numpy as np
import scipy
import sys
from operator import eq
from sympy import *

# For user input
n = int(input("Enter no of links: "))

q = [sympify("q{}".format(j)) for j in range(n)] 
q_dot = [sympify("q{}_dot".format(j)) for j in range(n)]  
q_ddot = [sympify("q{}_ddot".format(j)) for j in range(n)] 

# D(q) matrix from the user in terms of q
D = eye(n)
for i in range(n):
    for j in range(n):
        D[i,j] = sympify(input("enter element d({},{}): ".format(i,j)))

V = sympify(input("enter V: ")) 

# equations of motion 

for k in range(n):
    temp=0
    temp1=0
    for j in range(n):
        temp = temp + D[k,j]*q_ddot[j]
    for i in range(n):
        for j in range(n):
            temp1 = temp1 (diff(D[k,j],q[i]) - 0.5*diff(D[i,j],q[k])) * q_dot[i]*q_dot[j]
    temp2 = diff(V,q[k])
    Tau = sympify("T({})".format(k))

    temp3 = sympify(temp+temp1-temp2)

    print('Tau=', temp3)