import numpy as np
import math

def Jacobian(theta, phi, psi, l1, l2, l3):
    J = np.zeros((6,3))
    J[0][0] = -l1*math.sin(theta) - l2*math.sin(theta+phi) - l3*math.sin(theta+phi+psi)
    J[0][1] = -l2*math.sin(theta+phi) - l3*math.sin(theta+phi+psi)
    J[0][2] = -l3*math.sin(theta+phi+psi)
    J[1][0] = l1*math.cos(theta) + l2*math.cos(theta+phi) + l3*math.cos(theta+phi+psi)
    J[1][1] = l2*math.cos(theta+phi) + l3*math.cos(theta+phi+psi)
    J[1][2] = l3*math.cos(theta+phi+psi)
    J[5][0] = 1
    J[5][1] = 1
    J[5][2] = 1

    return J