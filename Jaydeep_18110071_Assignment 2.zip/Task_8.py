import numpy as np
import math

class Task_8:

    def matrixMultiplication(self,x,y):

        matrix_product = np.zeros((len(x, len(y[0]))))
        for i in range(len(x)):
            for j in range(len(y[0])):
                for k in range(len(y)):
                    matrix_product[i][j] += x[i][k] * y[k][j]
        return matrix_product

    def stanfordConfiguration(self, theta, phi, d, l1, l2):

        H0_1 = [ [math.cos(theta), -math.sin(theta), 0, 0],
                [math.sin(theta), math.cos(theta), 0, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 1]]
        H1_2 = [ [math.cos(phi), -math.sin(phi), 0, 0],
                [0, 0, -1, 0],
                [math.sin(phi), math.cos(phi), 0, l1],
                [0, 0, 0, 1]]
        H2_3 = [ [0, 0, 1, l2],
                [0, 1, 0, 0],
                [-1, 0, 0, 0],
                [0, 0, 0, 1]]

        P2_3 = [[0], [0], [d], [1]]

        P3_0 = self.matrixMultiplication(H0_1, self.matrixMultiplication(H1_2, self.matrixMultiplication(H2_3, P2_3)))

        p3_0 = [P3_0[0], P3_0[1], P3_0[2]]
        
        return p3_0