from operator import eq
import numpy as np
from sympy import *

n = int(input("Enter the number of links: "))
V_q = sympify(input("enter V(q): "))
D_q = eye(n)
for i in range(n):
    for j in range(n):
        D_q[i,j] = sympify(input("enter element d({},{}): ".format(i,j))) 
q_ddot = [sympify("q{}_ddot".format(j)) for j in range(n)] 
q_dot = [sympify("q{}_dot".format(j)) for j in range(n)]   
q = [sympify("q{}".format(j)) for j in range(n)]

for i in range(n):
    x=0
    y=0
    for j in range(n):
        x += D_q[i,j]*q_ddot[j]
    for j in range(n):
        for k in range(n):
            y += (diff(D_q[i,k],q[j])-0.5*diff(D_q[j,k],q[i]))*q_dot[j]*q_dot[k]
    z = diff(V_q,q[i])
    tau = sympify("T({})".format(i))
    print("{} = {}".format(sympify(x+y-z),tau))