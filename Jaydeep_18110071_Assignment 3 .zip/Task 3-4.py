import numpy as np
import math

def skewSymm(x, y):
    z = np.array([[0,x[2],x[1]],[-x[2],0,x[0]],[-x[1],-x[0],0]])
    return np.matmul(z,y)


def transformationMatrix(L_var):
    a = L_var[0]
    alpha = L_var[1]
    d = L_var[2]
    theta = L_var[3]
    A = np.array([[[math.cos(theta),-math.sin(theta)*math.cos(alpha),math.sin(theta)*math.cos(alpha),a*math.cos(theta)],
                   [math.sin(theta),math.cos(theta)*math.cos(alpha),-math.cos(theta)*math.sin(alpha),a*math.sin(theta)],
                   [0,math.sin(alpha),math.cos(alpha),d],
                   [0,0,0,1]]])
    return A


def DH_para(n,L_var):
    A = np.zeros([n,4,4])
    for x in range(n):
        A[x-1] = transformationMatrix(L_var[n-1])
    T = np.zeros([n,4,4])
    for x in range(n):
        B = np.identity(4)
        for i in range(x+1):
            B = np.matmul(B,A[i])
        T[x] = B
    return T

def manipulatorJacobian(n,T):
    O = np.zeros([n,4])
    for i in range(n):
        O[i] = np.matmul(T[i], np.array([0,0,0,1]))
    O = np.delete(O,n,1)
    Z = np.zeros([n, 4])
    for i in range(n):
        Z[i] = np.matmul(T[i], np.array([0,0,1,0]))
    Z = np.delete(Z,n,1)
    J = np.zeros([6,n])
    for i in range(n):
        s1 = skewSymm(Z[i],(O[n-1]-O[i]))
        s2 = Z[i]
        J[:,i] = np.hstack((s1,s2))
    return O,Z,J

x = DH_para(3,[[0,0,0,0],[0,0,0,0],[0,0,0,0]])
y = manipulatorJacobian(3,x)
print(y)

#Task 4 was verified using the above code and several values 
#for both RRP configurations of Stadar manipulator as well as
#SCARA manipulator. 